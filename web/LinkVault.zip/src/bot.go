package main

import (
	"context"
	"log"
	"time"

	"github.com/chromedp/cdproto/network"
	"github.com/chromedp/chromedp"
)

func botLoop() {
	time.Sleep(15 * time.Second)
	for {
		reviewCycle()
		time.Sleep(25 * time.Second)
	}
}

func reviewCycle() {
	log.Printf("[bot] review cycle starting")
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	allocCtx, allocCancel := chromedp.NewExecAllocator(ctx,
		chromedp.ExecPath("/usr/bin/chromium"),
		chromedp.Flag("headless", true),
		chromedp.Flag("no-sandbox", true),
		chromedp.Flag("disable-gpu", true),
		chromedp.Flag("disable-dev-shm-usage", true),
	)
	defer allocCancel()
	cctx, ccancel := chromedp.NewContext(allocCtx,
		chromedp.WithLogf(func(format string, args ...interface{}) {}),
	)
	defer ccancel()

	if err := chromedp.Run(cctx,
		network.SetCookie("session", adminSID).WithDomain("127.0.0.1").WithPath("/"),
		chromedp.Navigate("http://127.0.0.1:80/moderation"),
		chromedp.Sleep(5*time.Second),
	); err != nil {
		log.Printf("[bot] review error: %v", err)
		return
	}
	log.Printf("[bot] moderation reviewed")
}
