package main

import (
	"fmt"
	"log"
	"net"
	"net/http"
)

func startInternal() {
	mux := http.NewServeMux()

	mux.HandleFunc("/internal/import", func(w http.ResponseWriter, r *http.Request) {
		ip, _, err := net.SplitHostPort(r.RemoteAddr)
		if err != nil || (ip != "127.0.0.1" && ip != "::1") {
			http.Error(w, "denied", http.StatusForbidden)
			return
		}
		filter := r.URL.Query().Get("filter")
		title := r.URL.Query().Get("title")
		if filter == "" {
			http.Error(w, `{"err":"filter required"}`, http.StatusBadRequest)
			return
		}
		internalAddItem(title, filter)
		w.Header().Set("Content-Type", "application/json")
		fmt.Fprintf(w, `{"ok":true,"queued":true,"source":"crawler"}`)
	})

	log.Println("[linkvault] internal crawler API on 127.0.0.1:8081")
	go http.ListenAndServe("127.0.0.1:8081", mux)
	log.Println("[linkvault] internal crawler API on [::1]:8081")
	log.Fatal(http.ListenAndServe("[::1]:8081", mux))
}
