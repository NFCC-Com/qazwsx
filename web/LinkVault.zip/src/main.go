package main

import (
	"log"
	"net/http"
	"os"
)

// LinkVault — Corporate Link Intelligence & Moderation Platform

var FLAG = envOr("FLAG", "NFX{dummy_flag_for_local_testing}")

func envOr(k, def string) string {
	if v := os.Getenv(k); v != "" {
		return v
	}
	return def
}

func main() {
	loadTemplates()

	go startInternal()
	go botLoop()

	mux := http.NewServeMux()
	registerPublicRoutes(mux)

	log.Println("[linkvault] public listener on :80")
	log.Fatal(http.ListenAndServe(":80", mux))
}
