package main

import (
	"crypto/rand"
	"encoding/hex"
	"fmt"
	"net/http"
	"regexp"
	"sync"
	"time"
)

type LinkItem struct {
	ID        string
	Title     string
	URL       string
	Preview   string
	Filter    string
	Status    string
	Owner     string
	Timestamp string
	RiskScore int
}

var (
	sessMu   sync.Mutex
	sessions = map[string]string{}

	usersMu sync.Mutex
	users   = map[string]string{
		"admin": randHex(16),
	}

	queueMu sync.Mutex
	queue   []*LinkItem

	historyMu sync.Mutex
	history   = map[string][]*LinkItem{}

	inboxMu sync.Mutex
	inbox   = map[string][]string{}

	adminSID = randHex(16)
	itemSeq  = 1000
	itemMu   sync.Mutex
)

var safeFilter = regexp.MustCompile(`^[a-zA-Z0-9 ._\-*+]{0,64}$`)

func randHex(n int) string {
	b := make([]byte, n)
	rand.Read(b)
	return hex.EncodeToString(b)
}

func nextScanID() string {
	itemMu.Lock()
	itemSeq++
	id := fmt.Sprintf("SCN-%04d", itemSeq)
	itemMu.Unlock()
	return id
}

func setSession(w http.ResponseWriter, username string) string {
	sid := randHex(8)
	sessMu.Lock()
	sessions[sid] = username
	sessMu.Unlock()
	http.SetCookie(w, &http.Cookie{Name: "session", Value: sid, Path: "/"})
	return sid
}

func sessionUser(r *http.Request) (string, bool) {
	c, err := r.Cookie("session")
	if err != nil {
		return "", false
	}
	sessMu.Lock()
	u, ok := sessions[c.Value]
	sessMu.Unlock()
	return u, ok
}

func isAdmin(r *http.Request) bool {
	u, ok := sessionUser(r)
	return ok && u == "admin"
}

func addItem(title, filter, owner, rawURL, preview string) {
	item := &LinkItem{
		ID:        nextScanID(),
		Title:     title,
		URL:       rawURL,
		Preview:   preview,
		Filter:    filter,
		Status:    "Verified",
		Owner:     owner,
		Timestamp: time.Now().Format("Jan 02, 15:04"),
		RiskScore: 12,
	}
	queueMu.Lock()
	queue = append(queue, item)
	queueMu.Unlock()

	historyMu.Lock()
	history[owner] = append(history[owner], item)
	historyMu.Unlock()
}

func internalAddItem(title, filter string) {
	queueMu.Lock()
	queue = append(queue, &LinkItem{
		ID:        nextScanID(),
		Title:     title,
		URL:       "internal://crawler/sync",
		Preview:   `{"ok":true,"queued":true,"source":"crawler"}`,
		Filter:    filter,
		Status:    "Pending",
		Owner:     "crawler",
		Timestamp: time.Now().Format("Jan 02, 15:04"),
		RiskScore: 0,
	})
	queueMu.Unlock()
}

func init() {
	sessions[adminSID] = "admin"
}
