package main

import (
	"errors"
	"fmt"
	"html/template"
	"io"
	"net"
	"net/http"
	"net/url"
	"strings"
	"time"

	"golang.org/x/net/idna"
)

var blockedHosts = map[string]bool{
	"admin.internal": true,
	"localhost":      true,
	"127.0.0.1":      true,
}

var httpClient = &http.Client{Timeout: 8 * time.Second}

func guardedFetch(rawURL string) (string, error) {
	u, err := url.Parse(rawURL)
	if err != nil {
		return "", errors.New("invalid url")
	}
	if u.Scheme != "http" && u.Scheme != "https" {
		return "", errors.New("unsupported scheme")
	}
	host := strings.ToLower(u.Hostname())
	if blockedHosts[host] {
		return "", errors.New("host is not allowed")
	}
	pretty, _ := idna.ToUnicode(host)
	port := u.Port()
	if port != "" {
		u.Host = net.JoinHostPort(pretty, port)
	} else {
		u.Host = pretty
	}
	resp, err := httpClient.Get(u.String())
	if err != nil {
		return "", fmt.Errorf("fetch failed: %v", err)
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(io.LimitReader(resp.Body, 4096))
	return string(body), nil
}

// ---- Template Loader ----

var (
	tmplLayout     *template.Template
	tmplLanding    *template.Template
	tmplLogin      *template.Template
	tmplRegister   *template.Template
	tmplDashboard  *template.Template
	tmplSubmit     *template.Template
	tmplHistory    *template.Template
	tmplReports    *template.Template
	tmplAdmin      *template.Template
	tmplDenied     *template.Template
	tmplNotFound   *template.Template
	tmplModeration *template.Template
)

func loadTemplates() {
	base := template.Must(template.ParseFiles("templates/layout.html"))
	parse := func(name string) *template.Template {
		t := template.Must(base.Clone())
		return template.Must(t.ParseFiles("templates/" + name))
	}
	tmplLanding = parse("landing.html")
	tmplLogin = parse("login.html")
	tmplRegister = parse("register.html")
	tmplDashboard = parse("dashboard.html")
	tmplSubmit = parse("submit.html")
	tmplHistory = parse("history.html")
	tmplReports = parse("reports.html")
	tmplAdmin = parse("admin.html")
	tmplDenied = parse("403.html")
	tmplNotFound = parse("404.html")

	tmplModeration = template.Must(template.ParseFiles("templates/moderation.html"))
}

// ---- Page Data Structs ----

type PageData struct {
	User       string
	ActiveTab  string
	Err        string
	Preview    string
	Notes      []string
	Items      []*LinkItem
	Stats      DashStats
	Flag       string
}

type DashStats struct {
	TotalScanned   int
	PendingReview  int
	ThreatsBlocked int
	APICallsToday  int
}

// ---- Public Route Handlers ----

func registerPublicRoutes(mux *http.ServeMux) {
	mux.HandleFunc("/", handleLanding)
	mux.HandleFunc("/login", handleLogin)
	mux.HandleFunc("/register", handleRegister)
	mux.HandleFunc("/logout", handleLogout)
	mux.HandleFunc("/dashboard", handleDashboard)
	mux.HandleFunc("/submit", handleSubmit)
	mux.HandleFunc("/history", handleHistory)
	mux.HandleFunc("/reports", handleReports)
	mux.HandleFunc("/api/share", handleShare)
	mux.HandleFunc("/admin", handleAdmin)
	mux.HandleFunc("/moderation", handleModeration)
	mux.HandleFunc("/flag", handleFlag)

	// Legacy redirect for old /inbox URL
	mux.HandleFunc("/inbox", func(w http.ResponseWriter, r *http.Request) {
		http.Redirect(w, r, "/reports", http.StatusFound)
	})
}

func handleLanding(w http.ResponseWriter, r *http.Request) {
	if r.URL.Path != "/" {
		handleNotFound(w, r)
		return
	}
	user, _ := sessionUser(r)
	if user != "" {
		http.Redirect(w, r, "/dashboard", http.StatusFound)
		return
	}
	tmplLanding.ExecuteTemplate(w, "layout.html", PageData{ActiveTab: "landing"})
}

func handleLogin(w http.ResponseWriter, r *http.Request) {
	if r.Method == "GET" {
		tmplLogin.ExecuteTemplate(w, "layout.html", PageData{ActiveTab: "login"})
		return
	}
	if r.Method == "POST" {
		r.ParseForm()
		u, p := r.FormValue("username"), r.FormValue("password")
		usersMu.Lock()
		pass, exists := users[u]
		usersMu.Unlock()
		if exists && pass == p {
			setSession(w, u)
			http.Redirect(w, r, "/dashboard", http.StatusFound)
			return
		}
		tmplLogin.ExecuteTemplate(w, "layout.html", PageData{ActiveTab: "login", Err: "Invalid credentials."})
		return
	}
	http.Error(w, "method", http.StatusMethodNotAllowed)
}

func handleRegister(w http.ResponseWriter, r *http.Request) {
	if r.Method == "GET" {
		tmplRegister.ExecuteTemplate(w, "layout.html", PageData{ActiveTab: "register"})
		return
	}
	if r.Method == "POST" {
		r.ParseForm()
		u, p := r.FormValue("username"), r.FormValue("password")
		if u == "" || p == "" {
			tmplRegister.ExecuteTemplate(w, "layout.html", PageData{ActiveTab: "register", Err: "Username and password are required."})
			return
		}
		usersMu.Lock()
		if _, exists := users[u]; exists {
			usersMu.Unlock()
			tmplRegister.ExecuteTemplate(w, "layout.html", PageData{ActiveTab: "register", Err: "Username taken."})
			return
		}
		users[u] = p
		usersMu.Unlock()
		setSession(w, u)
		http.Redirect(w, r, "/dashboard", http.StatusFound)
		return
	}
	http.Error(w, "method", http.StatusMethodNotAllowed)
}

func handleLogout(w http.ResponseWriter, r *http.Request) {
	if c, err := r.Cookie("session"); err == nil {
		sessMu.Lock()
		delete(sessions, c.Value)
		sessMu.Unlock()
	}
	http.Redirect(w, r, "/", http.StatusFound)
}

func handleDashboard(w http.ResponseWriter, r *http.Request) {
	user, ok := sessionUser(r)
	if !ok {
		http.Redirect(w, r, "/login", http.StatusFound)
		return
	}
	historyMu.Lock()
	userLinks := history[user]
	historyMu.Unlock()

	queueMu.Lock()
	pending := len(queue)
	queueMu.Unlock()

	stats := DashStats{
		TotalScanned:   len(userLinks) + 142, // seed with realistic base count
		PendingReview:  pending,
		ThreatsBlocked: 7,
		APICallsToday:  len(userLinks)*3 + 89,
	}
	tmplDashboard.ExecuteTemplate(w, "layout.html", PageData{User: user, ActiveTab: "dashboard", Stats: stats, Items: userLinks})
}

func handleSubmit(w http.ResponseWriter, r *http.Request) {
	user, ok := sessionUser(r)
	if !ok {
		http.Redirect(w, r, "/login", http.StatusFound)
		return
	}
	if r.Method == "GET" {
		tmplSubmit.ExecuteTemplate(w, "layout.html", PageData{User: user, ActiveTab: "submit"})
		return
	}
	if r.Method == "POST" {
		r.ParseForm()
		rawURL := r.FormValue("url")
		filter := r.FormValue("filter")
		if !safeFilter.MatchString(filter) {
			tmplSubmit.ExecuteTemplate(w, "layout.html", PageData{User: user, ActiveTab: "submit", Err: "Content policy tag contains unsupported characters."})
			return
		}
		preview, err := guardedFetch(rawURL)
		if err != nil {
			tmplSubmit.ExecuteTemplate(w, "layout.html", PageData{User: user, ActiveTab: "submit", Err: err.Error()})
			return
		}
		title := strings.TrimSpace(preview)
		if strings.HasPrefix(title, "{") {
			title = "Ingested Gateway Response"
		} else if len(title) > 80 {
			title = title[:80]
		}
		if title == "" {
			title = "Captured Ingestion"
		}
		addItem(title, filter, user, rawURL, preview)
		tmplSubmit.ExecuteTemplate(w, "layout.html", PageData{User: user, ActiveTab: "submit", Preview: preview, Err: "Queued for moderation review."})
		return
	}
	http.Error(w, "method", http.StatusMethodNotAllowed)
}

func handleHistory(w http.ResponseWriter, r *http.Request) {
	user, ok := sessionUser(r)
	if !ok {
		http.Redirect(w, r, "/login", http.StatusFound)
		return
	}
	historyMu.Lock()
	items := append([]*LinkItem{}, history[user]...)
	historyMu.Unlock()
	tmplHistory.ExecuteTemplate(w, "layout.html", PageData{User: user, ActiveTab: "history", Items: items})
}

func handleReports(w http.ResponseWriter, r *http.Request) {
	user, ok := sessionUser(r)
	if !ok {
		http.Redirect(w, r, "/login", http.StatusFound)
		return
	}
	inboxMu.Lock()
	notes := append([]string{}, inbox[user]...)
	inboxMu.Unlock()
	tmplReports.ExecuteTemplate(w, "layout.html", PageData{User: user, ActiveTab: "reports", Notes: notes})
}

func handleShare(w http.ResponseWriter, r *http.Request) {
	_, ok := sessionUser(r)
	if !ok {
		http.Error(w, `{"err":"auth"}`, http.StatusUnauthorized)
		return
	}
	to := r.URL.Query().Get("to")
	data := r.URL.Query().Get("d")
	if to == "" || data == "" {
		http.Error(w, `{"err":"params"}`, http.StatusBadRequest)
		return
	}
	inboxMu.Lock()
	inbox[to] = append(inbox[to], data)
	inboxMu.Unlock()
	w.Header().Set("Content-Type", "application/json")
	fmt.Fprintf(w, `{"ok":true,"shared":true}`)
}

func handleModeration(w http.ResponseWriter, r *http.Request) {
	if !isAdmin(r) {
		http.Error(w, "admin only", http.StatusForbidden)
		return
	}
	queueMu.Lock()
	items := append([]*LinkItem{}, queue...)
	queue = nil
	queueMu.Unlock()
	tmplModeration.Execute(w, struct{ Items []*LinkItem }{items})
}

func handleAdmin(w http.ResponseWriter, r *http.Request) {
	if !isAdmin(r) {
		w.WriteHeader(http.StatusForbidden)
		user, _ := sessionUser(r)
		tmplDenied.ExecuteTemplate(w, "layout.html", PageData{
			User:      user,
			ActiveTab: "admin",
		})
		return
	}
	user, _ := sessionUser(r)
	tmplAdmin.ExecuteTemplate(w, "layout.html", PageData{
		User:      user,
		ActiveTab: "admin",
		Flag:      FLAG,
	})
}

func handleFlag(w http.ResponseWriter, r *http.Request) {
	if !isAdmin(r) {
		http.Error(w, `{"err":"admin only"}`, http.StatusForbidden)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	fmt.Fprintf(w, `{"flag":%q}`, FLAG)
}

func handleNotFound(w http.ResponseWriter, r *http.Request) {
	w.WriteHeader(http.StatusNotFound)
	user, _ := sessionUser(r)
	tmplNotFound.ExecuteTemplate(w, "layout.html", PageData{
		User:      user,
		ActiveTab: "404",
	})
}
