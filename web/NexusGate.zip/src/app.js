'use strict';
const http = require('http');
const { handleRequest } = require('./lib/routes');
const { startBotWorker } = require('./lib/bot');

const PORT = process.env.BACKEND_PORT || 8080;

// Initialize background audit tasks
startBotWorker();

// Start internal identity vault service
const server = http.createServer((req, res) => {
  handleRequest(req, res);
});

server.listen(PORT, '127.0.0.1', () => {
  console.log(`[vault] listening on 127.0.0.1:${PORT}`);
});
