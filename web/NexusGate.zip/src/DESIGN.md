# NexusGate — Design System & Style Specification

> High-security corporate identity gateway and identity vault with quantum indigo luminescence, deep obsidian glassmorphism surfaces, and precision audit telemetry displays.

**Theme:** Quantum Indigo & Obsidian Cyber-Security Interface

NexusGate is an enterprise-grade corporate identity gateway and in-memory vault backend. The design system is crafted to convey zero-trust precision, cryptographic security, and enterprise infrastructure reliability. It features multi-layer glassmorphism, deep obsidian canvases (`#080a12`), precision typography (Inter + JetBrains Mono), cyber indigo accents (`#6366f1`), electric violet glows (`#8b5cf6`), and interactive telemetry components.

---

## 🎨 Design Tokens

### Color Palette

| Token Name | Value | Role |
|------------|-------|------|
| `--bg-void` | `#080a12` | Deep canvas background with subtle radial indigo ambient glow |
| `--bg-surface` | `#0e1220` | Secondary container & panel background |
| `--bg-glass` | `rgba(17, 24, 42, 0.75)` | Elevated glassmorphism cards with backdrop blur |
| `--border-glass` | `rgba(255, 255, 255, 0.08)` | Hairline borders for high-tech framing |
| `--indigo-primary` | `#6366f1` | Primary brand accent — logo, active states, main buttons |
| `--violet-accent` | `#8b5cf6` | Secondary gradient accent & ticket portal highlights |
| `--cyan-glow` | `#00f0ff` | Telemetry highlights, active session indicators |
| `--emerald-success` | `#10b981` | Gateway operational status, active session pills |
| `--rose-danger` | `#ef4444` | Session termination, deletion alerts, errors |
| `--text-pure` | `#f8fafc` | High-contrast headlines and active text |
| `--text-muted` | `#94a3b8` | Body prose, secondary metadata labels |
| `--text-dim` | `#475569` | Micro-labels, code timestamps |

---

## 🔤 Typography & Components

- **Primary Font:** Inter (Google Fonts)
- **Monospace Font:** JetBrains Mono (Google Fonts) for vault secret keys, tickets, and audit trails.
- **Glass Elevation:** `backdrop-filter: blur(16px); -webkit-backdrop-filter: blur(16px);`
- **Glow Shadow:** `box-shadow: 0 0 25px rgba(99, 102, 241, 0.18);`

### UI Architecture
1. **Frosted Navbar:** Brand lockup with live status pulse (`● GATEWAY ACTIVE`) and quick navigation.
2. **Telemetry Header:** Metrics display for Vault Replication, Active Identity, and Gate Latency.
3. **Vault Management Panel:** Tabular view of owner-scoped secrets with interactive `Show/Hide` masking and `Delete` action pills.
4. **Audit Trail Journal:** Real-time searchable list of session activities with client-side query filter.
5. **Master Ticket Inspector:** Privileged ticket viewer with copy-to-clipboard toast feedback.
