#!/bin/sh
set -e
node /app/app.js &
node /app/proxy.js &
wait
