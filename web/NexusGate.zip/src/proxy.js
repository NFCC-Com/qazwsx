'use strict';
// NexusGate Edge Proxy Service
// Handles routing, caching, and upstream proxying.

const http = require('http');
const { Client, interceptors } = require('undici');

const BACKEND_HOST = '127.0.0.1';
const BACKEND_PORT = 8080;
const BACKEND_ORIGIN = `http://${BACKEND_HOST}:${BACKEND_PORT}`;

// keep-alive agent for the generic forwarding path
const agent = new http.Agent({ keepAlive: true, maxSockets: 32 });

// cached dispatcher used only for ticket pages (edge cache)
const ticketClient = new Client(BACKEND_ORIGIN);
const ticketDispatcher = ticketClient.compose(interceptors.cache());

const HOP_BY_HOP = new Set([
  'connection', 'keep-alive', 'proxy-authenticate', 'proxy-authorization',
  'te', 'trailer', 'transfer-encoding', 'upgrade',
]);

function rebuildHeaders(req) {
  const headers = {};
  for (const key of Object.keys(req.headers)) {
    if (HOP_BY_HOP.has(key)) continue;
    headers[key] = req.headers[key];
  }
  headers.host = `${BACKEND_HOST}:${BACKEND_PORT}`;
  return headers;
}

const server = http.createServer({ maxHeaderSize: 128 * 1024 }, (req, res) => {
  // ---- 1. path ACL ----
  if (req.url.startsWith('/internal/')) {
    res.writeHead(403, { 'content-type': 'text/plain' });
    res.end('forbidden');
    return;
  }

  // ---- 2. ticket pages: edge-cached fetch ----
  if (req.method === 'GET' && req.url.startsWith('/tickets/')) {
    ticketDispatcher.request({
      origin: BACKEND_ORIGIN,
      path: req.url,
      method: req.method,
      headers: rebuildHeaders(req),
    }).then((r) => {
      res.writeHead(r.statusCode, r.headers);
      r.body.pipe(res);
    }).catch(() => {
      res.writeHead(502, { 'content-type': 'text/plain' });
      res.end('bad gateway');
    });
    return;
  }

  // ---- 3. generic forwarding: rebuild headers + pipe body ----
  const headers = rebuildHeaders(req);
  // explicit framing for requests with no visible body indicator
  if (!req.headers['content-length'] && !req.headers['transfer-encoding']) {
    headers['content-length'] = '0';
  }

  const breq = http.request({
    host: BACKEND_HOST,
    port: BACKEND_PORT,
    method: req.method,
    path: req.url,
    headers,
    agent,
  }, (bres) => {
    res.writeHead(bres.statusCode, bres.headers);
    bres.pipe(res);
  });
  breq.on('error', () => {
    try {
      res.writeHead(502, { 'content-type': 'text/plain' });
      res.end('bad gateway');
    } catch (_) { /* response already sent */ }
  });
  req.pipe(breq);
});

server.listen(80, '0.0.0.0', () => {
  console.log('[gateway] listening on :80');
});
