/**
 * NexusGate Corporate Identity Portal - Client Runtime
 */
function showToast(message, type = 'info') {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.textContent = message;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px)';
    toast.style.transition = 'all 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

function copyTicket() {
  const el = document.querySelector('.ticket');
  if (!el) return;
  const text = el.innerText.trim();
  navigator.clipboard.writeText(text).then(() => {
    showToast('Master ticket copied to clipboard!', 'success');
  }).catch(() => {
    showToast('Failed to copy ticket.', 'error');
  });
}

function filterAuditLogs() {
  const input = document.getElementById('audit-search-input');
  if (!input) return;
  const query = input.value.toLowerCase();
  const items = document.querySelectorAll('ul.audit li');
  let matchCount = 0;

  items.forEach(li => {
    const text = li.innerText.toLowerCase();
    if (text.includes(query)) {
      li.style.display = 'flex';
      matchCount++;
    } else {
      li.style.display = 'none';
    }
  });

  const emptyMsg = document.getElementById('audit-empty-filter');
  if (emptyMsg) {
    emptyMsg.style.display = matchCount === 0 ? 'block' : 'none';
  }
}

function toggleSecret(btn) {
  const cell = btn.closest('td');
  if (!cell) return;
  const masked = cell.querySelector('.masked-secret');
  const real = cell.querySelector('.real-secret');
  if (!masked || !real) return;

  const isCurrentlyHidden = real.style.display === 'none' || window.getComputedStyle(real).display === 'none';

  if (isCurrentlyHidden) {
    real.style.display = 'inline-block';
    masked.style.display = 'none';
    btn.textContent = 'Hide';
  } else {
    real.style.display = 'none';
    masked.style.display = 'inline-block';
    btn.textContent = 'Show';
  }
}

function openSecretModal() {
  const modal = document.getElementById('secret-modal');
  if (modal) {
    modal.style.display = 'flex';
  }
}

function closeSecretModal() {
  const modal = document.getElementById('secret-modal');
  if (modal) {
    modal.style.display = 'none';
  }
}

// Global window assignments for inline event handlers
window.toggleSecret = toggleSecret;
window.openSecretModal = openSecretModal;
window.closeSecretModal = closeSecretModal;
window.copyTicket = copyTicket;
window.showToast = showToast;
window.filterAuditLogs = filterAuditLogs;

document.addEventListener('DOMContentLoaded', () => {
  const searchInput = document.getElementById('audit-search-input');
  if (searchInput) {
    searchInput.addEventListener('input', filterAuditLogs);
  }
});
