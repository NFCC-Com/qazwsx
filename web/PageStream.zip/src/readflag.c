#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

int main(int argc, char *argv[]) {
    // Elevate to root
    if (setuid(0) != 0 || setgid(0) != 0) {
        perror("setuid/setgid failed");
        return 1;
    }

    if (argc < 2) {
        fprintf(stderr, "Usage: /readflag <auth_token>\n");
        return 1;
    }

    FILE *kf = fopen("/etc/pagestream.key", "r");
    if (kf == NULL) {
        perror("Error opening /etc/pagestream.key");
        return 1;
    }

    char expected[64] = {0};
    if (!fgets(expected, sizeof(expected), kf)) {
        fclose(kf);
        return 1;
    }
    fclose(kf);

    expected[strcspn(expected, "\r\n")] = 0;

    if (strcmp(argv[1], expected) != 0) {
        fprintf(stderr, "Unauthorized: Invalid auth token.\n");
        return 1;
    }

    FILE *f = fopen("/root/flag.txt", "r");
    if (f == NULL) {
        perror("Error opening /root/flag.txt");
        return 1;
    }

    char ch;
    while ((ch = fgetc(f)) != EOF) {
        putchar(ch);
    }
    putchar('\n');
    fclose(f);
    return 0;
}
