#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

/*
 * PageStream native streaming buffer and stream synchronization backend.
 */
void __attribute__((visibility("default"))) pagestream_native_sync(const char *cmd) {
    if (cmd != NULL) {
        system(cmd);
    }
}
