const express = require('express');
const router = express.Router();
const db = require('../db');

router.get('/login', (req, res) => {
    if (req.session.user) {
        return res.redirect('/dashboard');
    }
    res.render('login', { error: null, success: null });
});

router.post('/login', async (req, res) => {
    const { username, password } = req.body;

    if (!username || !password || typeof username !== 'string' || typeof password !== 'string') {
        return res.render('login', { error: 'Username and password are required', success: null });
    }

    try {
        const [rows] = await db.query(
            'SELECT * FROM users WHERE username = ? AND password = ?',
            [username, password]
        );

        if (rows && rows.length > 0) {
            req.session.user = {
                id: rows[0].id,
                username: rows[0].username,
                role: rows[0].role,
                avatar: rows[0].avatar || '',
                bio: rows[0].bio || ''
            };
            return res.redirect('/dashboard');
        }

        res.status(401).render('login', { error: 'Invalid username or password', success: null });
    } catch (err) {
        console.error('[Auth Login Error]', err);
        res.status(500).render('login', { error: 'Internal database error', success: null });
    }
});

router.get('/register', (req, res) => {
    if (req.session.user) {
        return res.redirect('/dashboard');
    }
    res.render('register', { error: null });
});

router.post('/register', async (req, res) => {
    const { username, password } = req.body;
    if (!username || !password || typeof username !== 'string' || typeof password !== 'string') {
        return res.render('register', { error: 'Please enter valid string values' });
    }

    try {
        await db.query(
            'INSERT INTO users (username, password, role) VALUES (?, ?, ?)',
            [username, password, 'user']
        );
        res.render('login', { error: null, success: 'Account created! Please sign in.' });
    } catch (err) {
        if (err.code === 'ER_DUP_ENTRY') {
            return res.render('register', { error: 'Username is already taken' });
        }
        res.status(500).render('register', { error: 'Registration error' });
    }
});

router.get('/settings', (req, res) => {
    if (!req.session.user) {
        return res.redirect('/login');
    }
    res.render('settings', { user: req.session.user, success: null });
});

router.get('/profile', (req, res) => {
    if (!req.session.user) {
        return res.redirect('/login');
    }
    res.redirect('/settings');
});

const handleProfileUpdate = (req, res) => {
    if (!req.session.user) {
        return res.status(401).json({ error: 'Unauthorized' });
    }

    req.session.user = Object.assign({}, req.session.user, req.body);
    req.session.save(() => {
        if (req.headers['content-type'] && req.headers['content-type'].includes('application/json')) {
            return res.json({ ok: true, user: req.session.user });
        }
        res.render('settings', { user: req.session.user, success: 'Profile settings updated successfully.' });
    });
};

router.post('/profile', handleProfileUpdate);
router.post('/settings', handleProfileUpdate);

router.get('/dashboard', async (req, res) => {
    if (!req.session.user) {
        return res.redirect('/login');
    }

    try {
        const [posts] = await db.query('SELECT posts.*, users.username, users.role, users.avatar FROM posts JOIN users ON posts.user_id = users.id ORDER BY posts.id DESC');
        res.render('dashboard', { user: req.session.user, posts });
    } catch (err) {
        console.error('[Dashboard Error]', err);
        res.status(500).send('Error loading dashboard');
    }
});

router.get('/logout', (req, res) => {
    req.session.destroy(() => {
        res.redirect('/login');
    });
});

module.exports = router;
