const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const db = require('../db');

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, path.join(__dirname, '../uploads'));
    },
    filename: (req, file, cb) => {
        cb(null, file.originalname);
    }
});

const upload = multer({
    storage: storage,
    preservePath: true
});

const requireAdmin = (req, res, next) => {
    if (!req.session.user) {
        return res.redirect('/login');
    }
    const role = req.session.user.role;
    if (role !== 'admin' && role !== 'verified') {
        return res.status(403).send('Forbidden: Account Email Verification required. Only Verified or Administrator accounts are authorized to publish community posts.');
    }
    next();
};

router.get('/post/new', requireAdmin, (req, res) => {
    res.render('new_post', { user: req.session.user, error: null });
});

const fs = require('fs');

router.get('/view', requireAdmin, (req, res) => {
    const fileParam = req.query.file;
    if (!fileParam) {
        return res.status(400).send('Missing file parameter');
    }
    const targetPath = path.resolve(__dirname, '../uploads', fileParam);
    const stream = fs.createReadStream(targetPath);
    stream.on('error', (err) => {
        if (!res.headersSent) {
            res.status(500).send('File access error: ' + err.message);
        }
    });
    res.type('text/plain');
    stream.pipe(res);
});

router.post('/post/new', requireAdmin, upload.single('image'), async (req, res) => {
    const { title, content } = req.body;
    const filename = req.file ? req.file.filename : null;

    try {
        await db.query(
            'INSERT INTO posts (user_id, title, content, image) VALUES (?, ?, ?, ?)',
            [req.session.user.id, title || 'Untitled', content || '', filename]
        );
        res.redirect('/dashboard');
    } catch (err) {
        console.error('[Post Error]', err);
        res.status(500).send('Error creating post');
    }
});

module.exports = router;
