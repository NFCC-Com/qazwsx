#!/bin/sh
set -e

# Generate dynamic authentication key for secure flag retrieval daemon
node -e 'require("fs").writeFileSync("/etc/pagestream.key", require("crypto").randomBytes(16).toString("hex"))'
chmod 644 /etc/pagestream.key

echo "[+] Waiting for MySQL database..."
while ! nc -z db 3306; do
  sleep 1
done
echo "[+] MySQL database is ready."

echo "[+] Starting supervisord..."
exec /usr/bin/supervisord -c /etc/supervisor/conf.d/supervisord.conf
