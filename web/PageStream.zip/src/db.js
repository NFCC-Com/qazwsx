const mysql = require('mysql2/promise');

const pool = mysql.createPool({
    host: process.env.DB_HOST || 'db',
    user: process.env.DB_USER || 'pagestream',
    password: process.env.DB_PASSWORD || 'super_secret_db_pass',
    database: process.env.DB_NAME || 'pagestream',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});

module.exports = pool;
