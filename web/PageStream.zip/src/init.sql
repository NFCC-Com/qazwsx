DROP DATABASE IF EXISTS `pagestream`;
CREATE DATABASE `pagestream`;
USE `pagestream`;

CREATE TABLE IF NOT EXISTS `users` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `username` VARCHAR(64) NOT NULL UNIQUE,
    `password` VARCHAR(255) NOT NULL,
    `role` VARCHAR(32) DEFAULT 'user',
    `avatar` VARCHAR(512) DEFAULT 'https://images.unsplash.com/photo-1511367461989-f85a21fda167?w=100&auto=format&fit=crop&q=80',
    `bio` TEXT,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS `posts` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT NOT NULL,
    `title` VARCHAR(255) NOT NULL,
    `content` TEXT,
    `image` VARCHAR(512),
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
);

-- Seed realistic author accounts
INSERT INTO `users` (`username`, `password`, `role`, `avatar`, `bio`) VALUES
('admin', SHA2(CONCAT(NOW(), UUID(), 'admin_rnd_salt'), 256), 'admin', 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80', 'PageStream System Administrator & Chief Editor.'),
('elena_reads', SHA2(CONCAT(NOW(), UUID(), 'elena_rnd_salt'), 256), 'verified', 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&auto=format&fit=crop&q=80', 'Anime, Manga & Literary Fiction Enthusiast.'),
('kenji_tokyo', SHA2(CONCAT(NOW(), UUID(), 'kenji_rnd_salt'), 256), 'verified', 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&auto=format&fit=crop&q=80', 'Tokyo Culinary Photographer & Ramen Connoisseur.'),
('sophia_lit', SHA2(CONCAT(NOW(), UUID(), 'sophia_rnd_salt'), 256), 'verified', 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&auto=format&fit=crop&q=80', 'Sci-Fi & Cyberpunk Book Reviewer.'),
('marcus_dev', SHA2(CONCAT(NOW(), UUID(), 'marcus_rnd_salt'), 256), 'verified', 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&auto=format&fit=crop&q=80', 'Backend Architect & Terminal Hacker.'),
('clara_dune', SHA2(CONCAT(NOW(), UUID(), 'clara_rnd_salt'), 256), 'verified', 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100&auto=format&fit=crop&q=80', 'Speculative Fiction & Epic Fantasy Scholar.'),
('guest', SHA2(CONCAT(NOW(), UUID(), 'guest_rnd_salt'), 256), 'user', 'https://images.unsplash.com/photo-1511367461989-f85a21fda167?w=100&auto=format&fit=crop&q=80', 'Casual Reader & Community Observer.')
ON DUPLICATE KEY UPDATE id=id;

-- Seed 10 realistic community posts mapped to realistic authors
INSERT INTO `posts` (`user_id`, `title`, `content`, `image`) VALUES
(2, 'Frieren: Beyond Journey\'s End — A Masterpiece of Melancholy & Passage of Time', 'Frieren isn\'t just an anime about defeating the Demon King; it is a profound reflection on immortality, memory, and how fleeting human connections shape our brief lives. The animation by Madhouse and Evan Call\'s soundtrack elevate every episode into poetry.', 'https://images.unsplash.com/photo-1578632767115-351597cf2477?w=800&auto=format&fit=crop&q=80'),
(3, 'The Art of Tonkotsu Ramen: 18-Hour Broth Perfection in Shinjuku', 'Rich pork marrow broth simmered slowly for 18 hours until it turns milky white, paired with hand-crafted thin noodles, tender chashu pork belly, and a perfectly jammy ajitsuke tamago egg. Truly comfort food at its peak.', 'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?w=800&auto=format&fit=crop&q=80'),
(4, 'Re-reading Neuromancer by William Gibson in 2026', '"The sky above the port was the color of television, tuned to a dead channel." Forty years later, Gibson\'s vision of cyberspace, artificial intelligence, and corporate neon dystopias remains astonishingly prophetic.', 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=800&auto=format&fit=crop&q=80'),
(2, 'Morning Espresso & Chapter 4 of Haruki Murakami\'s Kafka on the Shore', 'Nothing beats a quiet Sunday morning with a double shot of Ethiopian Yirgacheffe espresso and Murakami\'s surrealistic prose. Cats talking, fish falling from the sky, and deep existential solitude.', 'https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?w=800&auto=format&fit=crop&q=80'),
(5, 'Why Distributed Event Loops & Async I/O Power Modern Web Backends', 'Understanding how single-threaded event loops handle thousands of concurrent TCP sockets via non-blocking epoll/kqueue multiplexing. Systems architecture is as much about mechanical sympathy as code optimization.', 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=800&auto=format&fit=crop&q=80'),
(2, 'The Magic of Background Art in Studio Ghibli\'s Spirited Away', 'Every hand-painted background by Kazuo Oga tells a story. The lush green train tracks submerged in water and silent spirit stations evoke a feeling of nostalgia that modern CGI rarely replicates.', 'https://images.unsplash.com/photo-1534447677768-be436bb09401?w=800&auto=format&fit=crop&q=80'),
(3, 'Rainy Nights in Shibuya Crossing — 35mm Film Excerpts', 'Captured on Kodak Portra 400 with a vintage 35mm f/1.4 lens. The reflection of glowing neon signs against wet asphalt creates an unmatched cinematic mood.', 'https://images.unsplash.com/photo-1503899036084-c55cdd92da26?w=800&auto=format&fit=crop&q=80'),
(3, 'Uji Ceremonial Grade Matcha: Traditional Preparation Notes', 'Whisked at 80°C with a bamboo chasen until a thick jade froth develops. The umami sweetness and slight astringency offer calm focus for long writing sessions.', 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?w=800&auto=format&fit=crop&q=80'),
(6, 'Dune Messiah: Frank Herbert\'s Warning Against Charismatic Leaders', 'While the first Dune is a classic hero\'s journey, Dune Messiah dismantles Paul Atreides\' mythos, demonstrating the terrifying consequences of blind fanaticism and prophetic foresight.', 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=800&auto=format&fit=crop&q=80'),
(5, 'Crafting a Distraction-Free Terminal & Editor Workflow', 'Vim keybindings, tmux session management, and a clean dark theme. Minimizing context switches lets you stay in the flow state for hours.', 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=800&auto=format&fit=crop&q=80')
ON DUPLICATE KEY UPDATE id=id;
