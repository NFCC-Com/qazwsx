# On-Call Checklist

## Shift Harian
- Cek dashboard latency & error rate di Grafana (netmetrics-internal).
- Pantau disk usage pada cluster storage dan node-03.
- Verifikasi backup database harian selesai sebelum 04:00 UTC.

## Prosedur Eskalasi Insiden
- P3 / P4: Tindak lanjuti pada jam kerja berikutnya.
- P1 / P2: Eskalasi langsung ke SRE Lead via PagerDuty / Slack #infra-war-room.
