# Infra Runbooks

Kumpulan runbook dan script operasional rutin tim infrastruktur NetMetrics.
Semua perubahan konfigurasi wajib melalui review tim sebelum dideploy ke production.
Untuk prosedur darurat dan on-call, silakan lihat [docs/oncall.md](docs/oncall.md).
