#!/bin/bash
# Log rotation script for NetMetrics service nodes
set -euo pipefail

LOG_DIR="/var/log/app"
RETENTION_DAYS=7

if [ -d "$LOG_DIR" ]; then
    echo "[+] Rotating logs older than $RETENTION_DAYS days in $LOG_DIR..."
    find "$LOG_DIR" -type f -name "*.log" -mtime +"$RETENTION_DAYS" -exec gzip -v {} \;
    find "$LOG_DIR" -type f -name "*.gz" -mtime +30 -delete
fi
